<?php

namespace App\Models;

use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Hash;

class User extends Authenticatable
{
    use Notifiable;
    use SoftDeletes;

    const ROL_ADMIN = 1;
    const ROL_OPERATOR = 2;
    const ROL_REQUESTER = 3;
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];


    public function rol()
    {
        return $this->belongsTo('App\Models\Role', 'rol_id');
    }

    public static function saveUser($request)
    {
        $user = new self();

        $user->rol_id = $request->rol_id;
        $user->firstname = ucfirst(strtolower($request->firstname));
        $user->lastname = ucfirst(strtolower($request->lastname));
        $user->email = $request->email;
        $user->password = Hash::make($request->password);
        $user->user_status = $request->user_status;
        $user->save();

        #Guardamos en Activity Log
        ActivityLog::saveActivityLog($user, 'saveUser', [
            'users' => $user
        ]);

        return $user;
    }



    public static function updateUser($request)
    {
        $obj = new self();
        $user = $obj->find($request->id);

        $user->rol_id = $request->rol_id;
        $user->firstname = ucfirst(strtolower($request->firstname));
        $user->lastname = ucfirst(strtolower($request->lastname));
        $user->email = $request->email;
        $user->user_status = $request->user_status;
        $user->save();

        #Guardamos en Activity Log
        ActivityLog::saveActivityLog($user, 'updateUser', [
            'users' => $user
        ]);

        return $user;
    }



    public static function deleteUser($id)
    {
        $user = self::find($id);
        self::find($id)->delete();

        #Guardamos en Activity Log
        ActivityLog::saveActivityLog($user, 'deleteUser', [
            'users' => $user
        ]);

        return $user;
    }
}
