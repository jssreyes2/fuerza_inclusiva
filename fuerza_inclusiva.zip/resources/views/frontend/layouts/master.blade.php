<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>.:: FUERZA INCLUSIVA ::.</title>
    <meta name="csrf-token" content="{{ csrf_token() }}">
    @include('frontend.layouts.css')
</head>
<body>

<div id="preloader">
    <div id="status">
        <div class="spinner">
            <div class="double-bounce1"></div>
            <div class="double-bounce2"></div>
        </div>
    </div>
</div>

@include('frontend.layouts.menu')
@yield('content')

<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-12 mb-0 mb-md-4 pb-0 pb-md-2"><a href="javascript:void(0)"><img src="images/logo-light.png" height="20" alt=""></a>
                <p class="mt-4">Espacio para descripción extra</p>
                <ul class="social-icon social list-inline mb-0">
                    <li class="list-inline-item"><a href="#" class="rounded"><i class="mdi mdi-facebook"></i></a></li>
                    <li class="list-inline-item"><a href="#" class="rounded"><i class="mdi mdi-twitter"></i></a></li>
                    <li class="list-inline-item"><a href="#" class="rounded"><i class="mdi mdi-instagram"></i></a></li>
                    <li class="list-inline-item"><a href="#" class="rounded"><i class="mdi mdi-google"></i></a></li>
                </ul>
            </div>
            <div class="col-lg-3 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0"><p class="text-white mb-4 footer-list-title">Sobre Fuerza Inclusiva</p>
                <ul class="list-unstyled footer-list">
                    <li><a href="#" class="text-foot"><i class="mdi mdi-chevron-right"></i> Sobre Nosotros</a></li>
                </ul>
            </div>
            <div class="col-lg-3 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0"><p class="text-white mb-4 footer-list-title">Recursos</p>
                <ul class="list-unstyled footer-list">
                    <li><a href="#" class="text-foot"><i class="mdi mdi-chevron-right"></i> Soporte</a></li>
                    <li><a href="#" class="text-foot"><i class="mdi mdi-chevron-right"></i> Privacidad</a></li>
                    <li><a href="#" class="text-foot"><i class="mdi mdi-chevron-right"></i> Términos</a></li>
                </ul>
            </div>
            <div class="col-lg-3 col-md-4 col-12 mt-4 mt-sm-0 pt-2 pt-sm-0"><p class="text-white mb-4 footer-list-title f-17">Horario de soporte</p>
                <ul class="list-unstyled text-foot mt-4 mb-0">
                    <li>Lunes - Viernes : 9:00 to 17:00</li>
                    <li class="mt-2">Sábado : 10:00 to 15:00</li>
                </ul>
            </div>
        </div>
    </div>
</footer><!-- footer end -->
<hr>
<footer class="footer footer-bar">
    <div class="container text-center">
        <div class="row justify-content-center">
            <div class="col-12">
                <div class=""><p class="mb-0">© 2021 Copyright Fuerza Inclusiva - Todos los derechos reservados</p></div>
            </div>
        </div>
    </div>
</footer>

<a href="#" class="back-to-top rounded text-center" id="back-to-top"> <i class="mdi mdi-chevron-up d-block"> </i></a>
@include('frontend.layouts.js')
</body>
</html>