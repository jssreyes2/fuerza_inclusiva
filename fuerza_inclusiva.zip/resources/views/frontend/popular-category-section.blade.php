<section class="section">

    <div class="container">

        <div class="row justify-content-center">

            <div class="col-12">

                <div class="section-title text-center mb-4 pb-2">

                    <h4 class="title title-line pb-5">Categorías Populares</h4>

                    <p class="text-muted para-desc mx-auto mb-1">Elige la categoría que te interese.</p>

                </div>

            </div>

        </div>

        <div class="row">

            <div class="col-lg-3 col-md-6 mt-4 pt-2">

                <a href="javascript:void(0)">

                    <div class="popu-category-box bg-light rounded text-center p-4">

                        <div class="popu-category-icon mb-3">

                            <i class="mdi mdi-account d-inline-block rounded-pill h3 text-primary"></i>

                        </div>

                        <div class="popu-category-content">

                            <h5 class="mb-2 text-dark title">Ejemplo</h5>

                            <p class="text-success mb-0 rounded">780 Puestos</p>

                        </div>

                    </div>

                </a>

            </div>

            <div class="col-lg-3 col-md-6 mt-4 pt-2">

                <a href="javascript:void(0)">

                    <div class="popu-category-box bg-light rounded text-center p-4">

                        <div class="popu-category-icon mb-3">

                            <i class="mdi mdi-desktop-classic d-inline-block rounded-pill h3 text-primary"></i>

                        </div>

                        <div class="popu-category-content">

                            <h5 class="mb-2 text-dark title">Ejemplo</h5>

                            <p class="text-success mb-0 rounded">1270 Puestos</p>

                        </div>

                    </div>

                </a>

            </div>

            <div class="col-lg-3 col-md-6 mt-4 pt-2">

                <a href="javascript:void(0)">

                    <div class="popu-category-box bg-light rounded text-center p-4">

                        <div class="popu-category-icon mb-3">

                            <i class="mdi mdi-bank d-inline-block rounded-pill h3 text-primary"></i>

                        </div>

                        <div class="popu-category-content">

                            <h5 class="mb-2 text-dark title">Ejemplo</h5>

                            <p class="text-success mb-0 rounded">2024 Puestos</p>

                        </div>

                    </div>

                </a>

            </div>

            <div class="col-lg-3 col-md-6 mt-4 pt-2">

                <a href="javascript:void(0)">

                    <div class="popu-category-box bg-light rounded text-center p-4">

                        <div class="popu-category-icon mb-3">

                            <i class="mdi mdi-auto-fix d-inline-block rounded-pill h3 text-primary"></i>

                        </div>

                        <div class="popu-category-content">

                            <h5 class="mb-2 text-dark title">Ejemplo</h5>

                            <p class="text-success mb-0 rounded">786 Puestos</p>

                        </div>

                    </div>

                </a>

            </div>

            <div class="col-lg-3 col-md-6 mt-4 pt-2">

                <a href="javascript:void(0)">

                    <div class="popu-category-box bg-light rounded text-center p-4">

                        <div class="popu-category-icon mb-3">

                            <i class="mdi mdi-office-building d-inline-block rounded-pill h3 text-primary"></i>

                        </div>

                        <div class="popu-category-content">

                            <h5 class="mb-2 text-dark title">Ejemplo</h5>

                            <p class="text-success mb-0 rounded">2156 Puestos</p>

                        </div>

                    </div>

                </a>

            </div>

            <div class="col-lg-3 col-md-6 mt-4 pt-2">

                <a href="javascript:void(0)">

                    <div class="popu-category-box bg-light rounded text-center p-4">

                        <div class="popu-category-icon mb-3">

                            <i class="mdi mdi-telegram d-inline-block rounded-pill h3 text-primary"></i>

                        </div>

                        <div class="popu-category-content">

                            <h5 class="mb-2 text-dark title">Ejemplo</h5>

                            <p class="text-success mb-0 rounded">256 Puestos</p>

                        </div>

                    </div>

                </a>

            </div>

            <div class="col-lg-3 col-md-6 mt-4 pt-2">

                <a href="javascript:void(0)">

                    <div class="popu-category-box bg-light rounded text-center p-4">

                        <div class="popu-category-icon mb-3">

                            <i class="mdi mdi-television-classic d-inline-block rounded-pill h3 text-primary"></i>

                        </div>

                        <div class="popu-category-content">

                            <h5 class="mb-2 text-dark title">Ejemplo</h5>

                            <p class="text-success mb-0 rounded">585 Puestos</p>

                        </div>

                    </div>

                </a>

            </div>

            <div class="col-lg-3 col-md-6 mt-4 pt-2">

                <a href="javascript:void(0)">

                    <div class="popu-category-box bg-light rounded text-center p-4">

                        <div class="popu-category-icon mb-3">

                            <i class="mdi mdi-human d-inline-block rounded-pill h3 text-primary"></i>

                        </div>

                        <div class="popu-category-content">

                            <h5 class="mb-2 text-dark title">Ejemplo</h5>

                            <p class="text-success mb-0 rounded">548 Puestos</p>

                        </div>

                    </div>

                </a>

            </div>

        </div>



        <div class="row justify-content-center">

            <div class="col-12 text-center mt-4 pt-2">

                <a href="javascript:void(0)" class="btn btn-primary-outline">Navega todas las categorías <i class="mdi mdi-chevron-right"></i></a>

            </div>

        </div>

    </div>

</section>