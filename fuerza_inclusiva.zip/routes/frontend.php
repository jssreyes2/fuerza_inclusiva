<?php

use Illuminate\Support\Facades\Route;

Auth::routes();

Route::match(['get', 'post'], '/', 'Auth\LoginController@showFrmLogin')->name('login-user');

Route::match(['get', 'post'], 'dashboard/logout', 'Auth\LoginController@logout')->name('logout');



Route::group(['prefix' => '/', 'middleware' => ['auth', 'check_role_dashboard']], function () {

    Route::match(['get', 'post'], 'jobs', 'JobsController@index')->name('jobs');

    Route::match(['get', 'post'], 'post-a-job', 'PostAJobController@index')->name('post-a-job');

    Route::match(['get', 'post'], 'candidate-list', 'CandidateListController@index')->name('candidate-list');

    Route::match(['get', 'post'], 'company-detail', 'CompanyDetailController@index')->name('company-detail');

    Route::match(['get', 'post'], 'contact', 'ContactController@index')->name('contact');
});




Route::match(['get', 'post'], 'dashboard/register', 'Auth\RegisterController@showRegistrationForm')->name('register');

Route::match(['get', 'post'], 'dashboard/save-user', 'Auth\RegisterController@store')->name('save-user');

//Route::match(['get', 'post'],' /jobs', function () {
//    return view('frontend.index');
//});


#Route::get('/', 'HomeController@index')->name('home');