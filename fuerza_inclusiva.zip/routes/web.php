<?php

include('backend/backend.php');
include('backend/settings.php');
include('backend/registers.php');
include('backend/users.php');
include('backend/landing-page.php');
include('frontend.php');
